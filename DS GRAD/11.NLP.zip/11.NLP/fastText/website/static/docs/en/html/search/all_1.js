var searchData=
[
  ['binary',['binary',['../structfasttext_1_1Node.html#a567bed8e85aa54f73371420f1b42dcda',1,'fasttext::Node']]],
  ['binarylogistic',['binaryLogistic',['../classfasttext_1_1Model.html#a953cbd5ace20826dcc1453bb94e99de0',1,'fasttext::Model']]],
  ['bow',['BOW',['../classfasttext_1_1Dictionary.html#a1024c006f9f04d04653ea529f33888ec',1,'fasttext::Dictionary']]],
  ['bucket',['bucket',['../classfasttext_1_1Args.html#a5534e863c25fa270fd0e27792723f6cb',1,'fasttext::Args']]],
  ['buildtree',['buildTree',['../classfasttext_1_1Model.html#aadfc3b7eb7bbe05f024fbfb67ea25ffd',1,'fasttext::Model']]]
];
