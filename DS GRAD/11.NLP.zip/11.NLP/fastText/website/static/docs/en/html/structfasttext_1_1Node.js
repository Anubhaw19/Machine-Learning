var structfasttext_1_1Node =
[
    [ "binary", "structfasttext_1_1Node.html#a567bed8e85aa54f73371420f1b42dcda", null ],
    [ "count", "structfasttext_1_1Node.html#a76430b0ffbb3b8f217435b11e4f51118", null ],
    [ "left", "structfasttext_1_1Node.html#a44f47a277a7fc982be30569befc7d8c1", null ],
    [ "parent", "structfasttext_1_1Node.html#a57d838e16a5dbb34aa0548a20843cf09", null ],
    [ "right", "structfasttext_1_1Node.html#a8a02d78386d6837a20858269bf9c6366", null ]
];