var searchData=
[
  ['zero',['zero',['../classfasttext_1_1Matrix.html#a44eee2d614a0cce8396cd33ecb7439ba',1,'fasttext::Matrix::zero()'],['../classfasttext_1_1Vector.html#af0cd17b1bbdf212780c31e427e982793',1,'fasttext::Vector::zero()']]]
];
