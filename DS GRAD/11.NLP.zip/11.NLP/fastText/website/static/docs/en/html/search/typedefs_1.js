var searchData=
[
  ['real',['real',['../namespacefasttext.html#a7afdad102f318271c14154b8e65e5ea3',1,'fasttext']]]
];
