var searchData=
[
  ['cbow',['cbow',['../classfasttext_1_1FastText.html#a592036d3a8ae545637db4864dbe5274f',1,'fasttext::FastText::cbow()'],['../namespacefasttext.html#a349df214746a2ea0e5d7c26326b03d6fae4709295b2cc44d67facf32b1099f1af',1,'fasttext::cbow()']]],
  ['centroids_5f',['centroids_',['../classfasttext_1_1ProductQuantizer.html#a56ed1ae67f47e95f2d1f4c6146d4913a',1,'fasttext::ProductQuantizer']]],
  ['checkmodel',['checkModel',['../classfasttext_1_1FastText.html#a7a874ab83984dc05dca56a74edae25c1',1,'fasttext::FastText']]],
  ['codes',['codes',['../classfasttext_1_1Model.html#ab6675d265df22787dfa9835196300d3b',1,'fasttext::Model']]],
  ['codes_5f',['codes_',['../classfasttext_1_1QMatrix.html#acc957d3d66b58cb9381f6a0556096c93',1,'fasttext::QMatrix']]],
  ['codesize_5f',['codesize_',['../classfasttext_1_1QMatrix.html#a4a69f60ba96c0b1a9da22c3951eca759',1,'fasttext::QMatrix']]],
  ['comparepairs',['comparePairs',['../classfasttext_1_1Model.html#ac475c67452b62dd374b6253f99167816',1,'fasttext::Model']]],
  ['compute_5fcode',['compute_code',['../classfasttext_1_1ProductQuantizer.html#a1b6fedf0a199ed0ec1afc2aea26a4b37',1,'fasttext::ProductQuantizer']]],
  ['compute_5fcodes',['compute_codes',['../classfasttext_1_1ProductQuantizer.html#aca0eb5cd10d5bba60b4f3f37f87676f6',1,'fasttext::ProductQuantizer']]],
  ['computehidden',['computeHidden',['../classfasttext_1_1Model.html#ae561523a8c81dd60d9bbe10336f83110',1,'fasttext::Model']]],
  ['computeoutputsoftmax',['computeOutputSoftmax',['../classfasttext_1_1Model.html#a00f5b7ed6e10c2bafa29919136c471f6',1,'fasttext::Model::computeOutputSoftmax(Vector &amp;, Vector &amp;) const'],['../classfasttext_1_1Model.html#af48ca152068185f0bd31746be56c03bd',1,'fasttext::Model::computeOutputSoftmax()']]],
  ['computesubwords',['computeSubwords',['../classfasttext_1_1Dictionary.html#ac175ccc5be52cd4b048c7ef4e1fa316e',1,'fasttext::Dictionary::computeSubwords(const std::string &amp;, std::vector&lt; int32_t &gt; &amp;) const'],['../classfasttext_1_1Dictionary.html#a1af5a16259f201bb08819cc2de938ecf',1,'fasttext::Dictionary::computeSubwords(const std::string &amp;, std::vector&lt; int32_t &gt; &amp;, std::vector&lt; std::string &gt; &amp;) const']]],
  ['count',['count',['../structfasttext_1_1entry.html#ab1f793678a1669b826d48f8b9ddcee6a',1,'fasttext::entry::count()'],['../structfasttext_1_1Node.html#a76430b0ffbb3b8f217435b11e4f51118',1,'fasttext::Node::count()']]],
  ['cutoff',['cutoff',['../classfasttext_1_1Args.html#aecc2b6243e3fa7c8da1b6d1205da8df0',1,'fasttext::Args']]]
];
