var searchData=
[
  ['fasttext',['FastText',['../classfasttext_1_1FastText.html',1,'fasttext']]]
];
